/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package myMetaphone;

/**
 *
 * @author Ankita
 */
public class demo {

    public static void main(String args[]){
    System.out.println(new String(" 							 div clas entry content 								 pre clas genericfont b   b hm hm hm m hm m m hm kahin na kahin he voh diwani mujhse abhi he anjani kahin na kahin he voh diwani mujhse abhi he anjani oh ayegi kabhi to samne voh mera khwab meri zindagani b fe  b kahin na kahin he voh diwana mujhse abhi he anjana oh ayega kabhi to samne voh khwabon men he jiska ana jana kahin na kahin he voh diwana mujhse abhi he anjana b   b uske labon pe bikhri he lali khushbu he uski sandali maheki baharen baheke nazaren voh muskurake jab chali han ankhon men kajal zulfon men badal sab rang us men he chupa b fe  b ho kahin na kahin he voh diwana mujhse abhi he anjana oh ayega kabhi to samne voh khwabon men he jiska ana jana kahin na kahin he voh diwana mujhse abhi he anjana kya chahti hun kya sochti hun usko nahin he kuch khabar men rok lungi rahon men usko bachke voh jayega kidhar m jagi na soyi yadon men khoyi yeh kya mujhe ho gaya b   b ho kahin na kahin he voh diwani mujhse abhi he anjani b fe  b oh oh kahin na kahin he voh diwana mujhse abhi he anjana b   b oh ayegi kabhi to samne voh mera khwab meri zindagani pre 													 \n" +
"").replaceAll("\\s+", " ").trim());
    }
}
