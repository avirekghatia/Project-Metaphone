package myMetaphone;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import java.awt.Color;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextArea;


/*
 * myMetaphoneInterface.java
 *this is the desktop interface for the metaphone project 
 * Created on Jan 28, 2014, 12:48:21 PM
 */
/**
 *
 * @author Ankita
 */
public class myMetaphoneInterface extends javax.swing.JFrame {

    /**
     * Creates new form myMetaphoneInterface
     */
    static String lyric;
    Connection conn;
    PreparedStatement ps;
    PreparedStatement ps1;
    ResultSet rs;
    ResultSet rs1;
    int sid;

    public myMetaphoneInterface() {
        initComponents();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        lyricTxt = new javax.swing.JTextField();
        searchBtn = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        resultTxt = new javax.swing.JTextArea();
        approxiTxt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Matura MT Script Capitals", 1, 36)); // NOI18N
        jLabel1.setText("MuSeek");

        lyricTxt.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lyricTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lyricTxtActionPerformed(evt);
            }
        });

        searchBtn.setText("Search");
        searchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBtnActionPerformed(evt);
            }
        });

        resultTxt.setColumns(20);
        resultTxt.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        resultTxt.setForeground(new java.awt.Color(255, 51, 51));
        resultTxt.setRows(5);
        resultTxt.setDisabledTextColor(new java.awt.Color(255, 0, 0));
        resultTxt.setEnabled(false);
        resultTxt.setSelectedTextColor(new java.awt.Color(255, 102, 102));
        jScrollPane2.setViewportView(resultTxt);

        approxiTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                approxiTxtActionPerformed(evt);
            }
        });

        jLabel2.setText("Enter Lyrics");

        jLabel3.setText("Approximation of search");

        jLabel4.setText("Default 0.85");

        jLabel5.setText("Range: 0.75 to 1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(252, 252, 252)
                .addComponent(searchBtn)
                .addContainerGap(380, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(266, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(259, 259, 259))
            .addGroup(layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 576, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(approxiTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(33, 33, 33)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(lyricTxt, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(64, 64, 64))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(lyricTxt))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(approxiTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addGap(30, 30, 30)
                .addComponent(searchBtn)
                .addGap(34, 34, 34)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBtnActionPerformed
        try {

            resultTxt.setText("");
            float approx;
            resultTxt.setForeground(Color.red);
            lyric = lyricTxt.getText();
            resultTxt.setText("");
            Input i = new Input();
            if (approxiTxt.getText().equals("")) {
                i.appxpercent = (float) 0.75;
            } else {

                try {
                    i.appxpercent = Float.parseFloat(approxiTxt.getText());

                    if (i.appxpercent < 0.75) {
                        i.appxpercent = (float) 0.85;
                    } else if (i.appxpercent > 1) {
                        i.appxpercent = (float) 0.85;
                    }
                } catch (NumberFormatException ne) {
                    System.out.println("wrong number entered");
                    i.appxpercent = (float) 0.85;
                }
            }
            i.getInput(lyric);
            if (i.isresult == true) {
                sid = i.sid;
                System.out.println("i got the sid " + sid);
                String result = "";
                Class.forName("com.mysql.jdbc.Driver");
                conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/major", "root", "");

                String sq = "select fid from result where sid = " + sid + " order by rank";
                ps = (PreparedStatement) conn.prepareStatement(sq);
                rs = (ResultSet) ps.executeQuery();

                if (rs.first()) {
                    do {

                        int fid = rs.getInt(1);
                        //retriving fid
                        System.out.println(fid);
                        String sq1 = "select fname from filelink where fid=" + fid;
                        ps1 = (PreparedStatement) conn.prepareStatement(sq1);
                        rs1 = (ResultSet) ps1.executeQuery();
                        while (rs1.next()) {
                            result = result + rs1.getString(1) + "\n";
                        }
                    } while (rs.next());
                    resultTxt.setText(result);

                } else {
                    resultTxt.setText("No result found");
                }
            } else {
                if (i.isLongQuery == true) {
                    resultTxt.setText("Too long query to search!!");
                } else {
                    resultTxt.setText("Please enter valid search query!!");
                }
            }

        } catch (SQLException ex) {
            Logger.getLogger(myMetaphoneInterface.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(myMetaphoneInterface.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_searchBtnActionPerformed

    private void approxiTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_approxiTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_approxiTxtActionPerformed

    private void lyricTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lyricTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lyricTxtActionPerformed

    /**
     * @param args the command line arguments
     */
    public static String setLyric() {
        return lyric;
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new myMetaphoneInterface().setVisible(true);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField approxiTxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField lyricTxt;
    private javax.swing.JTextArea resultTxt;
    private javax.swing.JButton searchBtn;
    // End of variables declaration//GEN-END:variables

}
