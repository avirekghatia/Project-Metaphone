/*
 * The class is used to add the metaphone rules to be added to the metaphone tables namely, convertword and dropword
 */

/**
 *
 * @author Ankita
 */
package myMetaphone;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class createMetaphoneDb {
    
    public static void main(String args[])
    {
        final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
        final String DB_URL = "jdbc:mysql://localhost/";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root", "");
            PreparedStatement ps;
            String sql;
            conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/major", "root", "");

            sql = "Create table  if not exists convertword(priority integer, fromword varchar(255), toword varchar(255), Primary key(priority))";
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
 
            sql = "insert into convertword values(1,'ee','i' )";
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            sql = "insert into convertword values(2,'aa','a' )";
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            sql = "insert into convertword values(3,'uu','u' )";
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            sql = "insert into convertword values(4,'ii','i' )";
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
                        
            sql = "insert into convertword values(5,'oo','u' )";
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            
            sql = "insert into convertword values(6,'ae','e' )";
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
                
            sql = "insert into convertword values(7,'ai','e' )"; 
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            sql = "insert into convertword values(8,'ao','o' )"; 
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            sql = "insert into convertword values(9,'ei','e' )"; 
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            sql = "insert into convertword values(10,'eo','iyo' )"; 
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            sql = "insert into convertword values(11,'ea','iya' )"; 
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            sql = "insert into convertword values(12,'eu','iyu' )"; 
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            sql = "insert into convertword values(13,'io','iyo' )"; 
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            sql = "insert into convertword values(14,'ia','iya' )"; 
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            sql = "insert into convertword values(15,'ph','f' )"; 
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            sql = "insert into convertword values(16,'q','k' )"; 
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            
            // create table
            
            sql = "Create table  if not exists dropword(priority integer, fromdrop varchar(255), todrop varchar(255), Primary key(priority))";
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            //insert values into the table
            
            sql = "insert into dropword values(1,'ks','k' )"; 
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(parse1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(parse1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
